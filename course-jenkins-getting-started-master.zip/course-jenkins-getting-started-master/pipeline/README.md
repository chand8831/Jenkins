# pipeline notes

## ACE Editor Shortcuts

- This is the editor used for pipeline scripts as such it has shortcuts that are useful (some of the ones listed work):
  - <https://ace.c9.io/demo/keyboard_shortcuts.html>
